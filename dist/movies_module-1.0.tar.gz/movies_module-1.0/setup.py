from distutils.core import setup
setup(
	name = 'movies_module',
	version = '1.0',
	py_modules = ['movies_module'],
	author = 'case',
	author_email = 'qcypggs@qq.com',
	url = 'http://www.cypggs.com',
	description = 'A simple printer of nested lists',
)
