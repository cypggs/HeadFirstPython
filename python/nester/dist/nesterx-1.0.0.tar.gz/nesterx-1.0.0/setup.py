from distutils.core import setup

setup(
name = 'nesterx',
version = '1.0.0',
py_modules = ['nester'],
author = 'case',
author_email = 'qcypggs@qq.com',
url = 'http://www.chenyongping.cn',
description = 'A simple printer of nester lists',
)
